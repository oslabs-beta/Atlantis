declare const atlantis: (redisClient: any, schema: any) => (req: any, res: any, next: any) => Promise<any>;
export { atlantis };
//# sourceMappingURL=index.d.ts.map