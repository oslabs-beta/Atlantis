declare const restructureAST: (AST: any) => any;
export { restructureAST };
//# sourceMappingURL=restructureAST.d.ts.map