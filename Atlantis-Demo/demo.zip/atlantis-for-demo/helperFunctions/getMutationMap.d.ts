declare const getMutationMap: (schema: any) => any;
export { getMutationMap };
//# sourceMappingURL=getMutationMap.d.ts.map