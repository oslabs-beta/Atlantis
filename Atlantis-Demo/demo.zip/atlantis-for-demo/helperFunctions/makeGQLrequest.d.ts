declare const makeGQLrequest: (redisClient: any, schema: any, redisKey: any, queryMade: any, proto: any, operationType: any) => Promise<unknown>;
export { makeGQLrequest };
//# sourceMappingURL=makeGQLrequest.d.ts.map