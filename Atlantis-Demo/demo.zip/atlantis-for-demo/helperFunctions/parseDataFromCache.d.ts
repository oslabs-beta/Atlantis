declare function parseDataFromCache(cacheObj: any, fieldObj: any): any;
export { parseDataFromCache };
//# sourceMappingURL=parseDataFromCache.d.ts.map