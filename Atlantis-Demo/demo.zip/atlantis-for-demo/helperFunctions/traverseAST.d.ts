declare const traverseAST: (AST: any) => {
    queryStructure: {};
    queryArgs: any;
    operationType: any;
    parentFieldName: any;
    fieldArgs: any;
    argsName: any;
};
export { traverseAST };
//# sourceMappingURL=traverseAST.d.ts.map