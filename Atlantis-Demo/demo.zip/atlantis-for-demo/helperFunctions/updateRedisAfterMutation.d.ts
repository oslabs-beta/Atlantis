declare const updateRedisAfterMutation: (redisClient: any, schema: any, graphQLResponse: Object) => void;
export { updateRedisAfterMutation };
//# sourceMappingURL=updateRedisAfterMutation.d.ts.map