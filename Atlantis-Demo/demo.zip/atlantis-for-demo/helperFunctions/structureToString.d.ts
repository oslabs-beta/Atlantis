declare const structureToString: (queryStructure: any, queryArgs: any) => string;
export { structureToString };
//# sourceMappingURL=structureToString.d.ts.map