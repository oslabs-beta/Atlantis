declare const isSubset: (rootObj: any, subObj: any) => boolean;
export { isSubset };
//# sourceMappingURL=isSubset.d.ts.map