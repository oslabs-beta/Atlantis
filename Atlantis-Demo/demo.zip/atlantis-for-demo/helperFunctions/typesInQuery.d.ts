declare const typesInQuery: (graphQLResponse: any) => string[];
export { typesInQuery };
//# sourceMappingURL=typesInQuery.d.ts.map